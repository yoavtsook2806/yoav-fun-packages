import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const saveExerciseData: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const getUserData: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=user.d.ts.map