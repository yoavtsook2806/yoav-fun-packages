import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const getLatest: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const addTrainingPlan: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=trainings.d.ts.map