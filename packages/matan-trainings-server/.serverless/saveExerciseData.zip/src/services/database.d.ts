import { ExerciseCompletionData, UserProfile, TrainingPlan } from '../types';
/**
 * AWS DynamoDB database service
 * Simple NoSQL operations for JSON data
 */
export declare class DatabaseService {
    private client;
    private tablePrefix;
    constructor();
    private getTableName;
    getTrainingPlans(): Promise<TrainingPlan[]>;
    saveTrainingPlan(plan: TrainingPlan): Promise<boolean>;
    saveTrainingPlans(plans: TrainingPlan[]): Promise<boolean>;
    getUserProfile(userId: string): Promise<UserProfile | null>;
    saveUserProfile(profile: UserProfile): Promise<boolean>;
    getUserExerciseData(userId: string, fromDate?: string, toDate?: string): Promise<ExerciseCompletionData[]>;
    saveExerciseData(exerciseData: ExerciseCompletionData): Promise<boolean>;
    private updateUserLastActive;
    getAllUsers(): Promise<string[]>;
    clearAllDB(): Promise<boolean>;
    healthCheck(): Promise<boolean>;
}
export declare const db: DatabaseService;
//# sourceMappingURL=database.d.ts.map