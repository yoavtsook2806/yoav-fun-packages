/**
 * Trainerly Server Test Kit
 * Provides mock data and utilities for testing both server and client applications
 */
import { Coach, Exercise, TrainingPlan, Trainer, ExerciseSession } from '../types';
export declare const mockCoaches: Coach[];
export declare const mockExercises: Exercise[];
export declare const mockTrainingPlans: TrainingPlan[];
export declare const mockTrainers: Trainer[];
export declare const mockExerciseSessions: ExerciseSession[];
export declare const getCoachById: (coachId: string) => Coach | undefined;
export declare const getExercisesByCoachId: (coachId: string) => Exercise[];
export declare const getTrainingPlansByCoachId: (coachId: string) => TrainingPlan[];
export declare const getTrainersByCoachId: (coachId: string) => Trainer[];
export declare const getExerciseSessionsByTrainerId: (trainerId: string, limit?: number) => ExerciseSession[];
export declare const getExerciseSessionsByCoachId: (coachId: string, limit?: number) => ExerciseSession[];
export declare const createMockApiResponse: <T>(data: T, success?: boolean) => {
    statusCode: number;
    body: string;
    headers: {
        'Content-Type': string;
        'Access-Control-Allow-Origin': string;
    };
};
export declare const createMockListResponse: <T>(items: T[]) => {
    statusCode: number;
    body: string;
    headers: {
        'Content-Type': string;
        'Access-Control-Allow-Origin': string;
    };
};
export declare const testScenarios: {
    fullCoachScenario: {
        coach: Coach;
        exercises: Exercise[];
        trainingPlans: TrainingPlan[];
        trainers: Trainer[];
        sessions: ExerciseSession[];
    };
    emptyCoachScenario: {
        coach: Coach;
        exercises: never[];
        trainingPlans: never[];
        trainers: never[];
        sessions: never[];
    };
    trainerWithProgressScenario: {
        trainer: Trainer;
        sessions: ExerciseSession[];
    };
    trainerWithoutProgressScenario: {
        trainer: Trainer;
        sessions: never[];
    };
};
declare const _default: {
    coaches: Coach[];
    exercises: Exercise[];
    trainingPlans: TrainingPlan[];
    trainers: Trainer[];
    exerciseSessions: ExerciseSession[];
    utils: {
        getCoachById: (coachId: string) => Coach | undefined;
        getExercisesByCoachId: (coachId: string) => Exercise[];
        getTrainingPlansByCoachId: (coachId: string) => TrainingPlan[];
        getTrainersByCoachId: (coachId: string) => Trainer[];
        getExerciseSessionsByTrainerId: (trainerId: string, limit?: number) => ExerciseSession[];
        getExerciseSessionsByCoachId: (coachId: string, limit?: number) => ExerciseSession[];
        createMockApiResponse: <T>(data: T, success?: boolean) => {
            statusCode: number;
            body: string;
            headers: {
                'Content-Type': string;
                'Access-Control-Allow-Origin': string;
            };
        };
        createMockListResponse: <T>(items: T[]) => {
            statusCode: number;
            body: string;
            headers: {
                'Content-Type': string;
                'Access-Control-Allow-Origin': string;
            };
        };
    };
    scenarios: {
        fullCoachScenario: {
            coach: Coach;
            exercises: Exercise[];
            trainingPlans: TrainingPlan[];
            trainers: Trainer[];
            sessions: ExerciseSession[];
        };
        emptyCoachScenario: {
            coach: Coach;
            exercises: never[];
            trainingPlans: never[];
            trainers: never[];
            sessions: never[];
        };
        trainerWithProgressScenario: {
            trainer: Trainer;
            sessions: ExerciseSession[];
        };
        trainerWithoutProgressScenario: {
            trainer: Trainer;
            sessions: never[];
        };
    };
};
export default _default;
//# sourceMappingURL=index.d.ts.map