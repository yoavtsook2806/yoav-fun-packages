import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * Sync comprehensive trainee data to server
 * Rule: All data in local storage must also be saved to server
 * POST /trainers/{trainerId}/data
 */
export declare const syncTraineeData: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
/**
 * Get comprehensive trainee data from server
 * GET /trainers/{trainerId}/data
 */
export declare const getTraineeData: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=trainee-data.d.ts.map