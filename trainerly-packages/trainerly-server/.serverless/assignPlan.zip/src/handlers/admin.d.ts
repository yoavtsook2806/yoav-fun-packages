import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const clearDatabase: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
/**
 * Get all admin exercises (created by admin coaches)
 */
export declare const getAdminExercises: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=admin.d.ts.map