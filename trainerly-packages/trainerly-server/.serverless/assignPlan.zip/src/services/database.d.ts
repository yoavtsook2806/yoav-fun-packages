import { ExerciseCompletionData, UserProfile, TrainingPlan } from '../types';
/**
 * AWS DynamoDB database service
 * Simple NoSQL operations for JSON data
 */
export declare class DatabaseService {
    private client;
    private tablePrefix;
    constructor();
    private getTableName;
    getTrainingPlans(): Promise<TrainingPlan[]>;
    saveTrainingPlans(plans: TrainingPlan[]): Promise<boolean>;
    getUserProfile(userId: string): Promise<UserProfile | null>;
    saveUserProfile(profile: UserProfile): Promise<boolean>;
    getUserExerciseData(userId: string, fromDate?: string, toDate?: string): Promise<ExerciseCompletionData[]>;
    saveExerciseData(exerciseData: ExerciseCompletionData): Promise<boolean>;
    private updateUserLastActive;
    getAllUsers(): Promise<string[]>;
    clearAllDB(): Promise<boolean>;
    saveCoach(coach: any): Promise<boolean>;
    getCoach(coachId: string): Promise<any | null>;
    getCoachByEmail(email: string): Promise<any | null>;
    getCoachByNickname(nickname: string): Promise<any | null>;
    updateCoach(coach: any): Promise<boolean>;
    saveTrainer(trainer: any): Promise<boolean>;
    getTrainer(trainerId: string): Promise<any | null>;
    getTrainersByCoach(coachId: string): Promise<any[]>;
    saveExercise(exercise: any): Promise<boolean>;
    getExercisesByCoach(coachId: string): Promise<any[]>;
    deleteExercise(exerciseId: string): Promise<boolean>;
    updateExercise(exercise: any): Promise<boolean>;
    savePlan(plan: any): Promise<boolean>;
    getPlan(planId: string): Promise<any | null>;
    getPlansByCoach(coachId: string): Promise<any[]>;
    getPlansByTrainer(trainerId: string): Promise<any[]>;
    getAdminExercises(): Promise<any[]>;
    getExercise(exerciseId: string): Promise<any | null>;
    getTrainingPlan(planId: string): Promise<any | null>;
    saveTrainingPlan(plan: any): Promise<boolean>;
    updateTrainingPlan(plan: any): Promise<boolean>;
    deleteTrainingPlan(planId: string): Promise<boolean>;
    getCustomTrainingPlansForTrainee(coachId: string, traineeName: string): Promise<any[]>;
    saveExerciseSession(session: any): Promise<boolean>;
    getExerciseSessionsByTrainer(trainerId: string, limit?: number): Promise<any[]>;
    healthCheck(): Promise<boolean>;
    syncTraineeData(traineeId: string, data: {
        exerciseDefaults?: Record<string, any>;
        trainingProgress?: Record<string, any>;
        exerciseHistory?: Record<string, any[]>;
        firstTimeExperienceCompleted?: boolean;
        customExerciseData?: Record<string, any>;
    }): Promise<boolean>;
    getTraineeData(traineeId: string): Promise<any | null>;
    getTraineeDataForResponse(traineeId: string): Promise<{
        exerciseDefaults: Record<string, any>;
        trainingProgress: Record<string, any>;
        exerciseHistory: Record<string, any[]>;
        firstTimeExperienceCompleted?: boolean;
        customExerciseData?: Record<string, any>;
    }>;
}
export declare const db: DatabaseService;
//# sourceMappingURL=database.d.ts.map