/**
 * Comprehensive list of 30 gym exercises
 * Covers all body parts with variety for both men and women preferences
 * All names and descriptions in Hebrew, with short YouTube links (max 40 seconds)
 */
export declare const MUSCLE_GROUPS: readonly ["חזה עליון", "חזה תחתון", "חזה אמצעי", "גב עליון", "גב תחתון", "גב אמצעי", "גב רחב", "ירך קדמי", "ירך אחורי", "ישבן", "שוק", "כתף קדמית", "כתף צדדית", "כתף אחורית", "טרפז", "יד קדמית", "יד אחורית", "אמה", "בטן עליונה", "בטן תחתונה", "בטן צדדית", "ליבה", "ירך פנימי", "ירך חיצוני", "גוף מלא"];
export interface ExerciseTemplate {
    name: string;
    note: string;
    link: string;
    muscleGroup: string;
}
export declare const GYM_EXERCISES: ExerciseTemplate[];
export declare const getExercisesByMuscleGroup: (muscleGroup: string) => ExerciseTemplate[];
export declare const getRandomExercises: (count: number) => ExerciseTemplate[];
export declare const convertToServerExercise: (template: ExerciseTemplate, exerciseId: string, coachId?: string) => any;
//# sourceMappingURL=exercises.d.ts.map