import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * Create a new exercise session for a trainee
 * POST /trainers/{trainerId}/exercise-sessions
 */
export declare const createExerciseSession: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
/**
 * Get exercise sessions for a trainee
 * GET /trainers/{trainerId}/exercise-sessions
 */
export declare const getExerciseSessions: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
/**
 * Get exercise sessions for a trainee (coach view)
 * GET /coaches/{coachId}/trainers/{trainerId}/exercise-sessions
 */
export declare const getTrainerExerciseSessions: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=exercise-sessions.d.ts.map