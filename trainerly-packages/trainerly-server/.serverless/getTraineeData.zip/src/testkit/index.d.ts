/**
 * Trainerly Server Test Kit
 * Provides mock data and utilities for testing both server and client applications
 */
import { Coach, Exercise, TrainingPlan, Trainee, ExerciseSession } from '../types';
export declare const mockCoaches: Coach[];
export declare const mockExercises: Exercise[];
export declare const mockTrainingPlans: TrainingPlan[];
export declare const mockTrainees: Trainee[];
export declare const mockExerciseSessions: ExerciseSession[];
export declare const getCoachById: (coachId: string) => Coach | undefined;
export declare const getExercisesByCoachId: (coachId: string) => Exercise[];
export declare const getTrainingPlansByCoachId: (coachId: string) => TrainingPlan[];
export declare const getTraineesByCoachId: (coachId: string) => Trainee[];
export declare const getExerciseSessionsByTraineeId: (traineeId: string, limit?: number) => ExerciseSession[];
export declare const getExerciseSessionsByCoachId: (coachId: string, limit?: number) => ExerciseSession[];
export declare const createMockApiResponse: <T>(data: T, success?: boolean) => {
    statusCode: number;
    body: string;
    headers: {
        'Content-Type': string;
        'Access-Control-Allow-Origin': string;
    };
};
export declare const createMockListResponse: <T>(items: T[]) => {
    statusCode: number;
    body: string;
    headers: {
        'Content-Type': string;
        'Access-Control-Allow-Origin': string;
    };
};
export declare const testScenarios: {
    fullCoachScenario: {
        coach: Coach;
        exercises: Exercise[];
        trainingPlans: TrainingPlan[];
        trainees: Trainee[];
        sessions: ExerciseSession[];
    };
    emptyCoachScenario: {
        coach: Coach;
        exercises: never[];
        trainingPlans: never[];
        trainees: never[];
        sessions: never[];
    };
    traineeWithProgressScenario: {
        trainee: Trainee;
        sessions: ExerciseSession[];
    };
    traineeWithoutProgressScenario: {
        trainee: Trainee;
        sessions: never[];
    };
};
declare const _default: {
    coaches: Coach[];
    exercises: Exercise[];
    trainingPlans: TrainingPlan[];
    trainees: Trainee[];
    exerciseSessions: ExerciseSession[];
    utils: {
        getCoachById: (coachId: string) => Coach | undefined;
        getExercisesByCoachId: (coachId: string) => Exercise[];
        getTrainingPlansByCoachId: (coachId: string) => TrainingPlan[];
        getTraineesByCoachId: (coachId: string) => Trainee[];
        getExerciseSessionsByTraineeId: (traineeId: string, limit?: number) => ExerciseSession[];
        getExerciseSessionsByCoachId: (coachId: string, limit?: number) => ExerciseSession[];
        createMockApiResponse: <T>(data: T, success?: boolean) => {
            statusCode: number;
            body: string;
            headers: {
                'Content-Type': string;
                'Access-Control-Allow-Origin': string;
            };
        };
        createMockListResponse: <T>(items: T[]) => {
            statusCode: number;
            body: string;
            headers: {
                'Content-Type': string;
                'Access-Control-Allow-Origin': string;
            };
        };
    };
    scenarios: {
        fullCoachScenario: {
            coach: Coach;
            exercises: Exercise[];
            trainingPlans: TrainingPlan[];
            trainees: Trainee[];
            sessions: ExerciseSession[];
        };
        emptyCoachScenario: {
            coach: Coach;
            exercises: never[];
            trainingPlans: never[];
            trainees: never[];
            sessions: never[];
        };
        traineeWithProgressScenario: {
            trainee: Trainee;
            sessions: ExerciseSession[];
        };
        traineeWithoutProgressScenario: {
            trainee: Trainee;
            sessions: never[];
        };
    };
};
export default _default;
//# sourceMappingURL=index.d.ts.map