"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTraineeCustomPlans = exports.createCustomTrainingPlan = exports.identifyTrainer = exports.getTrainer = exports.listTrainers = exports.createTrainer = void 0;
const crypto_1 = require("crypto");
const database_1 = require("../services/database");
const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
};
const createTrainer = async (event) => {
    try {
        const coachId = event.pathParameters?.coachId;
        if (!coachId) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'VALIDATION_ERROR',
                    message: 'Coach ID is required'
                })
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'VALIDATION_ERROR',
                    message: 'Request body is required'
                })
            };
        }
        const requestData = JSON.parse(event.body);
        const { nickname, email } = requestData;
        if (!nickname) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'VALIDATION_ERROR',
                    message: 'Nickname is required'
                })
            };
        }
        // Check if nickname is unique per coach
        const existingTrainers = await database_1.db.getTrainersByCoach(coachId);
        const nicknameExists = existingTrainers.some(t => t.nickname.toLowerCase() === nickname.toLowerCase());
        if (nicknameExists) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'NICKNAME_TAKEN',
                    message: 'Nickname already exists for this coach'
                })
            };
        }
        // TODO: Verify JWT token and check if coach exists and is valid
        const trainer = {
            trainerId: (0, crypto_1.randomUUID)(),
            coachId,
            nickname,
            email,
            createdAt: new Date().toISOString()
        };
        await database_1.db.saveTrainer(trainer);
        const response = {
            trainerId: trainer.trainerId
        };
        return {
            statusCode: 201,
            headers,
            body: JSON.stringify(response)
        };
    }
    catch (error) {
        console.error('Error creating trainer:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'INTERNAL_ERROR',
                message: 'Internal server error'
            })
        };
    }
};
exports.createTrainer = createTrainer;
const listTrainers = async (event) => {
    try {
        const coachId = event.pathParameters?.coachId;
        if (!coachId) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'VALIDATION_ERROR',
                    message: 'Coach ID is required'
                })
            };
        }
        // TODO: Verify JWT token and check if coach exists and is valid
        const trainers = await database_1.db.getTrainersByCoach(coachId);
        const response = {
            items: trainers.map(trainer => ({
                trainerId: trainer.trainerId,
                firstName: trainer.firstName,
                lastName: trainer.lastName,
                email: trainer.email,
                createdAt: trainer.createdAt,
                plans: trainer.plans || []
            }))
        };
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify(response)
        };
    }
    catch (error) {
        console.error('Error listing trainers:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'INTERNAL_ERROR',
                message: 'Internal server error'
            })
        };
    }
};
exports.listTrainers = listTrainers;
const getTrainer = async (event) => {
    try {
        const coachId = event.pathParameters?.coachId;
        const trainerId = event.pathParameters?.trainerId;
        if (!coachId || !trainerId) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'VALIDATION_ERROR',
                    message: 'Coach ID and Trainer ID are required'
                })
            };
        }
        // TODO: Verify JWT token and check if coach exists and is valid
        const trainer = await database_1.db.getTrainer(trainerId);
        if (!trainer) {
            return {
                statusCode: 404,
                headers,
                body: JSON.stringify({
                    error: 'NOT_FOUND',
                    message: 'Trainer not found'
                })
            };
        }
        // Security check: Verify that this trainer belongs to the requesting coach
        if (trainer.coachId !== coachId) {
            return {
                statusCode: 403,
                headers,
                body: JSON.stringify({
                    error: 'FORBIDDEN',
                    message: 'Access denied: Trainer does not belong to this coach'
                })
            };
        }
        const response = {
            trainerId: trainer.trainerId,
            coachId: trainer.coachId,
            firstName: trainer.firstName,
            lastName: trainer.lastName,
            email: trainer.email,
            createdAt: trainer.createdAt
        };
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify(response)
        };
    }
    catch (error) {
        console.error('Error getting trainer:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'INTERNAL_ERROR',
                message: 'Internal server error'
            })
        };
    }
};
exports.getTrainer = getTrainer;
const identifyTrainer = async (event) => {
    try {
        if (!event.body) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'VALIDATION_ERROR',
                    message: 'Request body is required'
                })
            };
        }
        const requestData = JSON.parse(event.body);
        const { coachNickname, traineeNickname } = requestData;
        let trainer = null;
        if (coachNickname && traineeNickname) {
            // Identify by coach nickname + trainee nickname
            const coach = await database_1.db.getCoachByNickname(coachNickname.toLowerCase().trim());
            if (coach) {
                const trainers = await database_1.db.getTrainersByCoach(coach.coachId);
                trainer = trainers.find(t => t.nickname.toLowerCase() === traineeNickname.toLowerCase()) || null;
            }
        }
        else {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'VALIDATION_ERROR',
                    message: 'coachNickname and traineeNickname are required'
                })
            };
        }
        if (!trainer) {
            return {
                statusCode: 404,
                headers,
                body: JSON.stringify({
                    error: 'NOT_FOUND',
                    message: 'Trainer not found'
                })
            };
        }
        const response = {
            trainerId: trainer.trainerId,
            coachId: trainer.coachId
        };
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify(response)
        };
    }
    catch (error) {
        console.error('Error identifying trainer:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'INTERNAL_ERROR',
                message: 'Internal server error'
            })
        };
    }
};
exports.identifyTrainer = identifyTrainer;
/**
 * Create a custom training plan for a specific trainee
 */
const createCustomTrainingPlan = async (event) => {
    try {
        const coachId = event.pathParameters?.coachId;
        const trainerId = event.pathParameters?.trainerId;
        if (!coachId || !trainerId) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'VALIDATION_ERROR',
                    message: 'Coach ID and trainer ID are required'
                })
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'VALIDATION_ERROR',
                    message: 'Request body is required'
                })
            };
        }
        const { basePlanId, traineeName } = JSON.parse(event.body);
        if (!basePlanId || !traineeName) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'VALIDATION_ERROR',
                    message: 'Base plan ID and trainee name are required'
                })
            };
        }
        // Get the base training plan
        const basePlan = await database_1.db.getTrainingPlan(basePlanId);
        if (!basePlan || basePlan.coachId !== coachId) {
            return {
                statusCode: 404,
                headers,
                body: JSON.stringify({
                    error: 'NOT_FOUND',
                    message: 'Base training plan not found or not owned by coach'
                })
            };
        }
        // Create a custom plan for the trainee
        const customPlan = {
            ...basePlan,
            planId: (0, crypto_1.randomUUID)(),
            name: `${basePlan.name} - ${traineeName}`,
            customTrainee: traineeName,
            originalPlanId: basePlanId,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        const success = await database_1.db.saveTrainingPlan(customPlan);
        if (!success) {
            return {
                statusCode: 500,
                headers,
                body: JSON.stringify({
                    error: 'INTERNAL_ERROR',
                    message: 'Failed to create custom training plan'
                })
            };
        }
        return {
            statusCode: 201,
            headers,
            body: JSON.stringify(customPlan)
        };
    }
    catch (error) {
        console.error('Error creating custom training plan:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'INTERNAL_ERROR',
                message: 'Internal server error'
            })
        };
    }
};
exports.createCustomTrainingPlan = createCustomTrainingPlan;
/**
 * Get custom training plans for a specific trainee
 */
const getTraineeCustomPlans = async (event) => {
    try {
        const coachId = event.pathParameters?.coachId;
        const trainerId = event.pathParameters?.trainerId;
        if (!coachId || !trainerId) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'VALIDATION_ERROR',
                    message: 'Coach ID and trainer ID are required'
                })
            };
        }
        // Get trainee to get their name
        const trainee = await database_1.db.getTrainer(trainerId);
        if (!trainee || trainee.coachId !== coachId) {
            return {
                statusCode: 404,
                headers,
                body: JSON.stringify({
                    error: 'NOT_FOUND',
                    message: 'Trainee not found'
                })
            };
        }
        const traineeName = `${trainee.firstName} ${trainee.lastName}`;
        // Get custom plans for this trainee
        const customPlans = await database_1.db.getCustomTrainingPlansForTrainee(coachId, traineeName);
        // Convert to summary format
        const planSummaries = customPlans.map(plan => ({
            planId: plan.planId,
            name: plan.name,
            description: plan.description,
            trainingsCount: plan.trainings?.length || 0,
            isAdminPlan: plan.isAdminPlan,
            originalPlanId: plan.originalPlanId,
            customTrainee: plan.customTrainee,
            createdAt: plan.createdAt
        }));
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                items: planSummaries,
                count: planSummaries.length
            })
        };
    }
    catch (error) {
        console.error('Error getting trainee custom plans:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'INTERNAL_ERROR',
                message: 'Internal server error'
            })
        };
    }
};
exports.getTraineeCustomPlans = getTraineeCustomPlans;
//# sourceMappingURL=trainers.js.map