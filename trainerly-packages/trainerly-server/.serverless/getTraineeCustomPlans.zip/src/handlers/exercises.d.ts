import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const createExercise: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const listExercises: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const deleteExercise: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const updateExercise: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=exercises.d.ts.map